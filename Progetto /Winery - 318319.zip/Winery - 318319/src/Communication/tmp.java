package Communication;

import javax.swing.JOptionPane;

public class tmp{
    public static void main(String[] args){
       JOptionPane.showMessageDialog(null,"Test","ALERT",JOptionPane.INFORMATION_MESSAGE);
    }
}